# CS Dust2 Mobile

Android fullscreen WebView wrapper for the configured game URL. The game content is streamed from the original site, so internet is required and availability/performance depends on that site.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build APK(s).
4. Install the APK generated under `app/build/outputs/apk/debug/`.

Landscape mode, fullscreen, JavaScript and DOM storage are enabled. No game assets are bundled.
